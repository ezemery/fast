import React, { useState } from 'react';

import Header2 from '../../components/header2';
import Footer from '../../components/footer';
import Logo from './logo';
import Colours from './colours';
import Menu from './menu';

import './style.scss';

function Content(props) {
	const { current } = props;
	switch (current) {
		case 'Logo':
			return <Logo></Logo>;
		case 'Colours':
			return <Colours></Colours>;
	}
}
function Assets() {
	const [category, setCategory] = useState({ current: 'Logo' });
	return (
		<div className="assets-page">
			<Header2></Header2>
			<div className="assets-page-content">
				<Menu {...category} onMenuClicked={state => setCategory(state)}></Menu>
				<div className="assets-page-content-right">
					<Content {...category}></Content>
				</div>
			</div>
			<Footer></Footer>
		</div>
	);
}

export default Assets;
