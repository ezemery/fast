import React from 'react';

import './style.scss';

function Menu(props) {
	const { current, onMenuClicked } = props;
	const data = [
		{ type: 'heading', text: 'BRAND GUIDELINES' },
		{ type: 'item', text: 'Logo' },
		{ type: 'item', text: 'Colours' },
		{ type: 'item', text: 'Font Families' },
		{ type: 'item', text: 'Typography scale' },
		{ type: 'item', text: 'Iconography' },
		{ type: 'item', text: 'Buttons' },
		{ type: 'heading', text: 'ASSETS LIBRARY' },
		{ type: 'item', text: 'Templates' },
		{ type: 'item', text: 'Forms' },
		{ type: 'item', text: 'Illustrations' },
		{ type: 'item', text: 'Videos' },
		{ type: 'item', text: 'Imagery' },
		{ type: 'item', text: 'Iconography' },
	];
	return (
		<div className="assets-menu">
			{data.map(item => {
				return item.type === 'heading' ? (
					<div className="assets-menu-heading">{item.text}</div>
				) : (
					<div
						className={'assets-menu-item  ' + (current == item.text ? 'active' : '')}
						onClick={() => {
							onMenuClicked(item.text);
						}}
					>
						{item.text}
					</div>
				);
			})}
		</div>
	);
}

export default Menu;
